<?php
if(ccb_pro_active()) {
    do_action('render-multi-range-view');
}
